
    $(document).ready(function() 
    {
		"use strict";
        $('.tabs').tabs();
        
        jQuery.getScript('https://quanticalabs.com/.tools/EnvatoItems/js/getItems.js',function() { });
    });

